

<?php $__env->startSection('title','Prevycons - Novedades'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-red-600 flex flex-col  mx-auto h-auto text-slate-50">
        <div class="ml-10 mt-5">
            <br>
        </div>
        <div class="ml-10 mb-5 text-5xl">
            <h1>Novedades </h1> 
            <h1><br></h1>
        </div>
    </div>


    <br>
    <br>
    <div class="grid grid-cols-4 gap-4 box-border h-auto w-11/12 p-4 border-4 justify-center mx-auto">
   
        <a href="" class="box-border h-auto p-4 shadow-lg hover:shadow-2xl w-auto">    
            <div class="">
                <strong></strong>
            </div>
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\test-prevycons\resources\views/novedades.blade.php ENDPATH**/ ?>