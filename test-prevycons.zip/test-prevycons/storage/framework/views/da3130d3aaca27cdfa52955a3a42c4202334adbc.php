

<?php $__env->startSection('title','Prevycons - Servicio '. $servicios->name); ?>

<?php $__env->startSection('content'); ?>
    <img src="<?php echo e(URL::asset($servicios->img)); ?>" class="mx-auto w-1/12 justify-center" alt="logo-img">
    <h2><strong><?php echo e($servicios->name); ?></strong></h2>
    <br>
    <p class="px-8"><?php echo e($servicios->descripcion); ?></p>
    <br>
    <p class="px-8"><?php echo e($servicios->contenido); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\test-prevycons\resources\views/servicios/show.blade.php ENDPATH**/ ?>