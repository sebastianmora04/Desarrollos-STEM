

<?php $__env->startSection('title','Prevycons - Blog'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Blog - implementar</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\test-prevycons\resources\views/blog.blade.php ENDPATH**/ ?>