

<?php $__env->startSection('title','Prevycons - Quienes somos? '. $variable); ?>

<?php $__env->startSection('content'); ?>
    <h2>Soy <?php
        if($variable2){
            echo  "$variable $variable2";
        }else{
            echo  $variable;
        }
        ?>
    </h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\test-prevycons\resources\views/about-us/show.blade.php ENDPATH**/ ?>