
<?php $__env->startSection('title','Test'); ?>


<?php $__env->startSection('content'); ?>
    <h1>Contenido de test</h1>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\test-prevycons\resources\views/test.blade.php ENDPATH**/ ?>