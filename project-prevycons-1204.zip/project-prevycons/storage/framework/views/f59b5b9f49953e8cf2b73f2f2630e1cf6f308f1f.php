

<?php $__env->startSection('title','Prevycons - Home'); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-cyan-600 flex flex-col  mx-auto h-auto text-slate-50">
    <div class="ml-10 mt-5">
        <br>
    </div>
    <div class="ml-10 mb-5 sm:text-5xl text-3xl">
        <h1>Bienvenidos a Prevycons</h1> 
        <h1><br></h1>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\project-prevycons\resources\views/home.blade.php ENDPATH**/ ?>