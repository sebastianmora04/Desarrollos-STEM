

<?php $__env->startSection('title','Prevycons - Catálogo '.$producto->name); ?>

<?php $__env->startSection('content'); ?>

<p><?php echo e($producto->categoria); ?>   <?php echo e($producto->valoracion); ?></p>
<br>

<div class="grid grid-cols-2 gap-4">
    <div><img src="../img/productos/<?php echo e($producto->id); ?>.png" class="mx-auto w-1/3 justify-center" alt="logo-img"></div>
    <div class="my-auto">
        <?php echo e($producto->name); ?>

        <br>
        $ <?php echo e($producto->precio); ?>

    </div>
    
    <div><?php echo e($producto->descripcion); ?></div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\project-prevycons\resources\views/catalogo/show.blade.php ENDPATH**/ ?>