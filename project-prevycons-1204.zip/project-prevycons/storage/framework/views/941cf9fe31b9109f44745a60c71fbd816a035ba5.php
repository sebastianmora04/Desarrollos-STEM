<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Prueba 2 - </h1>

    <p>Procedimiento de envío de mails 2 - </p>

    <p><strong>Nombre: </strong><?php echo e($contacto['name']); ?></p>
    <p><strong>Correo electrónico: </strong><?php echo e($contacto['correo']); ?></p>
    <p><strong>Teléfono: </strong><?php echo e($contacto['telefono']); ?></p>
    <p><strong>Tema: </strong><?php echo e($contacto['tema']); ?></p>
    <p><strong>Descripción: </strong><?php echo e($contacto['descripcion']); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\testprevycons\project-prevycons\resources\views/contacto/contactanos.blade.php ENDPATH**/ ?>