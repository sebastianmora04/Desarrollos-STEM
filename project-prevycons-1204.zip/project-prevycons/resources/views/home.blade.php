@extends('layouts.plantilla')

@section('title','Prevycons - Home')

@section('content')

<div class="bg-cyan-600 flex flex-col  mx-auto h-auto text-slate-50">
    <div class="ml-10 mt-5">
        <br>
    </div>
    <div class="ml-10 mb-5 sm:text-5xl text-3xl">
        <h1>Bienvenidos a Prevycons</h1> 
        <h1><br></h1>
    </div>
</div>


@endsection