

<?php $__env->startSection('title','Prevycons - Servicio '. $servicios->name); ?>

<?php $__env->startSection('content'); ?>
    <a class="px-16" href="<?php echo e(route('servicios.index')); ?>">Regresar</a>
    <img src="<?php echo e(URL::asset($servicios->img)); ?>" class="mx-auto w-1/12 justify-center" alt="logo-img">
    <h2 class="mx-auto text-center"><strong><?php echo e($servicios->name); ?></strong></h2>
    <br>
    <p class="px-8"><?php echo e($servicios->descripcion); ?></p>
    <br>
    <p class="px-8"><?php echo e($servicios->contenido); ?></p>
    <br>
    <div>
        <ul class="px-16">
            <li><strong>Acciones a desarrollar</strong></li>
            <li> - Cómo desarrollar un plan de manejo ambiental</li>
            <li> - Reducción, reutilización y reciclaje de residuos sólidos</li>
            <li> - Prevención de riesgos</li>
            <li> - Buenas prácticas ambientales</li>
            <li> - Saneamiento ambiental</li>
            <li> - Capacitación “El Agua”</li>
            <li> - Capacitación Uso Racional y Ahorro de Energía</li>
            <li> - Gestión del riesgo</li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\project-prevycons\resources\views/servicios/unidad/4.blade.php ENDPATH**/ ?>