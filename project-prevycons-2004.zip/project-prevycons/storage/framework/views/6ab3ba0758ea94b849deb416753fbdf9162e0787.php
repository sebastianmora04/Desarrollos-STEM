

<?php $__env->startSection('title','Prevycons - Blog '. $blog->name); ?>

<?php $__env->startSection('content'); ?>
    <strong><?php echo e($blog->name); ?></strong>
    <p class="text-slate-400"><?php echo e($blog->categoria); ?></p>
    <br>
    <br>
    <p><?php echo e($blog->informacion); ?></p>
    <br>
    <a href="<?php echo e(route('blog.edit', $blog)); ?>">Editar post</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-prevycons\resources\views/blog/show.blade.php ENDPATH**/ ?>