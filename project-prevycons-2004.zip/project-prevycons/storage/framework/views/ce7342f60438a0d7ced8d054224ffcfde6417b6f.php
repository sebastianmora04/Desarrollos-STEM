

<?php $__env->startSection('title','Prevycons - Blog Create'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Create post</h1>
    <form action="<?php echo e(route('blog.store')); ?>" method="POST">

        <?php echo csrf_field(); ?> 

        <label>
            Name:
            <br>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>">
        </label>

        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
            <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <br>
        
        <label>
            Informacion: 
            <br> 
            <textarea name="informacion" rows="3"><?php echo e(old('informacion')); ?></textarea>
        </label>
        
        <?php $__errorArgs = ['informacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
            <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <br>

        <label>
            Categoría: 
            <br> 
            <input type="text" name="categoria" value="<?php echo e(old('categoria')); ?>">
        </label>
        
        <?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
            <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <br>
        
        <label>
            Imagen:
            <br>
            <input type="text">
        </label>
        <br>
        <br>
        <button type="submit">Publicar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\project-prevycons\resources\views/blog/create.blade.php ENDPATH**/ ?>