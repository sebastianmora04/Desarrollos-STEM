

<?php $__env->startSection('title','Prevycons - Blog'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-indigo-600 flex flex-col  mx-auto h-auto text-slate-50">
        <div class="ml-10 mt-5">
            <br>
        </div>
        <div class="ml-10 mb-5 text-5xl">
            <h1>Blog </h1> 
            <h1><br></h1>
        </div>
    </div>
    <br>
    <a href="<?php echo e(route('blog.create')); ?>" class="">
        <button class="ml-5 px-2 py-1 transition  hover:border-gray-500 hover:scale-105 ease-in-out rounded font-semibold text-indigo-600 border-2 border-gray-300">Crear post</button>
    </a>
    <br>
    <br>
    <div class="grid grid-cols-4 gap-4 box-border h-auto w-11/12 p-4 border-4 justify-center mx-auto">
    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('blog.show',$item->id)); ?>" class="box-border h-auto p-4 shadow-lg hover:shadow-2xl w-auto">    
            <div class="">
                <strong><?php echo e($item->name); ?></strong>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php echo e($blogs->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-prevycons\resources\views/blog/index.blade.php ENDPATH**/ ?>