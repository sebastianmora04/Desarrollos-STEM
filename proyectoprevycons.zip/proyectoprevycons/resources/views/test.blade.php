@extends('layouts.plantilla')
@section('title','Test')


@section('content')
    <h1>Contenido de test</h1>    
@endsection



<div class="flex flex-row">
    <div class="basis-1/6">
        
    </div>
    <div class="basis-1/12"></div>
    <div class="basis-4/6">
        <strong></strong>
        <br>
        
        <br>
        <br>
        
    </div>
</div>