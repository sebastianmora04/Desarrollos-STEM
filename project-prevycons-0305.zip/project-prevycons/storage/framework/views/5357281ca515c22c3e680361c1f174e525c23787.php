

<?php $__env->startSection('title','Prevycons - Servicios'); ?>

<?php $__env->startSection('head'); ?>
    <style>
        .linea {
        border-top: 3px solid rgb(207, 207, 207);
        height: 2px;
        padding: 0;
        margin: 20px auto 0 auto;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br>
    <div class="azul1 lg:px-24 md:px-16 sm:px-12  flex flex-col  mx-auto h-auto text-orange-500 titulos">
        <div class="ml-10 mt-5 sm:text-base text-sm">
            Nuestra pasión es el pensamiento creativo
        </div>
        <div class="ml-10 mb-5 sm:text-5xl text-3xl">
            <h1>El proveedor líder de soluciones </h1> 
            <h1>para clientes.</h1>
        </div>
    </div>
    <br>
    <div>
        <p></p>
    </div>
    <br>
    <div class="flex flex-col  mx-auto h-auto sm:text-3xl text-xl azul2">
        <div class="m-auto text-center sm:px-0 px-2 titulos">
            DISEÑO E IMPLEMENTACIÓN DE SISTEMAS DE GESTIÓN
        </div>
    </div>
    
    <br><br>

    <div class="grid lg:grid-cols-4 sm:grid-cols-2 grid-rows-2 gap-4  h-auto w-11/12 p-4 justify-center mx-auto">
        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row-span-2 ">
            <div class="box-border h-96 p-4 shadow-lg hover:shadow-2xl w-auto rounded-lg text-slate-50 w-11/12 mx-auto bg-gradient-to-t from-[#001559] to-[#254ecc]">
                <a href="<?php echo e(route('servicios.show',$item->id)); ?>">
                    <img src="<?php echo e($item->img); ?>" class="mx-auto w-3/5 justify-center"
                            alt="logo-img">
                    <br>
                    <div class="sm:text-base text-sm">
                        <p class="text-center titulos"><strong><?php echo e($item->name); ?></strong></p>
                       
                        <br><p class="sm:text-sm text-xs"><?php echo e($item->descripcion); ?></p>
                    </div>
                </a>
            </div> <!-- box-border h-auto p-4 shadow-lg hover:shadow-2xl w-auto -->
            <br>
            <a href="<?php echo e(route('servicios.show',$item->id)); ?>"><p class="text-center azul2 titulos md:text-xl">Ver Más</p></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <br><br>

    <div class="linea w-5/6"></div>
    <?php echo e($servicios->links()); ?>

    
    <br>

    <div class="flex flex-col  mx-auto h-auto sm:text-3xl text-xl azul2">
        <div class="m-auto text-center sm:px-0 px-2 titulos">
            OTROS SERVICIOS
        </div>
    </div>

    <br>

    <div class="grid lg:grid-cols-4 sm:grid-cols-2 gap-4  h-auto w-11/12 p-4  justify-center mx-auto">
        <?php $__currentLoopData = $servicios2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row-span-2 ">
            <div class="box-border h-96 p-4 shadow-lg hover:shadow-2xl w-auto rounded-lg text-slate-50 w-11/12 mx-auto bg-gradient-to-t from-[#001559] to-[#254ecc]">
                <a href="<?php echo e(route('servicios.show',$item->id)); ?>">
                    <img src="<?php echo e($item->img); ?>" class="mx-auto w-3/5 justify-center"
                            alt="logo-img">
                    <br>
                    <div class="sm:text-[15px] text-sm">
                        <p class="text-center titulos"><strong><?php echo e($item->name); ?></strong></p>
                        <br><p class="sm:text-[13px] text-xs"><?php echo e($item->descripcion); ?></p>
                    </div>
                </a>
            </div> <!-- box-border h-auto p-4 shadow-lg hover:shadow-2xl w-auto -->
            <br>
            <p class="text-center azul2 titulos md:text-xl">Ver Más</p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <br><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\project-prevycons\resources\views/servicios/index.blade.php ENDPATH**/ ?>