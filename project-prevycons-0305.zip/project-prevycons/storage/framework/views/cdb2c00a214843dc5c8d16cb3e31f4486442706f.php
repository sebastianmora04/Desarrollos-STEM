

<?php $__env->startSection('title','Prevycons - Servicio '. $servicios->name); ?>

<?php $__env->startSection('head'); ?>
    <style>    
    .volver{
        color: rgb(0, 21, 89);
        border-color: rgb(0, 21, 89)
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <img src="<?php echo e(URL::asset($servicios->img)); ?>" class="mx-auto w-1/6 justify-center" alt="logo-img">
    
    <br>

    <h2 class="mx-auto text-center azul2 titulos text-3xl px-[350px]"><strong><?php echo e($servicios->name); ?></strong></h2>
    
    <br>

    <div class="flex flex-row px-28 font-semibold" style="color: rgb(134, 133, 133)">

        <div class="basis-1/2 w-11/12 px-4">
            <p class=""><?php echo e($servicios->descripcion); ?></p>
            <br>
            <p class=""><?php echo e($servicios->contenido); ?></p>
            <br>
            <p class="">
            </p>

            <p class="titulos text-lg ">Entregables</p>
            <ul class="my-2 ">
                <li> - Identificación de peligros</li>
                <li> - Documentación del sistema</li>
                <li> - Sensibilización a empresas en SG- SST</li>
                <li> - COPASST- Conformación y funciones</li>
                <li> - Comité de convivencia laboral – Conformación y funciones</li>
                <li> - Investigación de accidentes e incidentes de trabajo</li>
                <li> - Conformación y capacitación a brigadas de emergencia</li>
                <li> - Auditoría y plan de mejora</li>
            </ul>

        </div>
    
        <div class="basis-1/2 w-11/12 px-2">
            <p class="titulos text-lg">Aplicación del sistema de gestión</p>
            <ul class="my-2">
                <li> - Pautas básicas orden y aseo</li>
                <li> - Uso adecuado de EPP</li>
                <li> - Trabajo en alturas</li>
                <li> - Gestión del riesgo</li>
                <li> - Preparación y atención de emergencias. Plan de emergencias, generalidades y requisitos legales</li>
                <li> - Qué son y qué hacer en Primeros auxilios</li>
                <li> - Brigada contra incendio sin práctica</li>
                <li> - Uso y almacenamiento de Sustancias químicas </li>
                <li> - Manejo defensivo y Seguridad vial</li>
                <li> - Seguridad para peatones</li>
                <li> - Manejo y uso seguro de herramientas manuales</li>
            </ul>

            <br>
            
            <p class="titulos text-lg">Sistema de vigilancia epidemiológica</p>
            <ul class="my-2">
                <li> - Levantamiento y desplazamiento manual de cargas</li>
                <li> - Cuidado de manos</li>
                <li> - Riesgo cardiovascular</li>
                <li> - Autocuidado y síndrome metabólico</li>
                <li> - Riesgo psicosocial</li>
                <li> - Autocuidado y espalda sana, higiene postural</li>
                <li> - Sensibilización de NO al consumo de Alcohol ni drogas</li>
                <li> - Capacitación de pausas saludables</li>
            </ul>

            <img src="" class="" alt="">

        </div>

    </div>

    <br>

    <a href="<?php echo e(route('servicios.index')); ?>"><button class="mx-32 px-4 py-1 transition hover:scale-105 ease-in-out rounded-full font-black border volver sm:text-xl text-lg " type="submit">Volver</button></a>

    <br><br>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\project-prevycons\resources\views/servicios/unidad/2.blade.php ENDPATH**/ ?>