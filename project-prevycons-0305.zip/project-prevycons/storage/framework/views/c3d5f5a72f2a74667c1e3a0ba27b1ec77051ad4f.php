

<?php $__env->startSection('title','Prevycons - Creada satisfactoriamente'); ?>

<?php $__env->startSection('head'); ?>
    <style>
        .linea {
        border-top: 3px solid rgb(207, 207, 207);
        height: 2px;
        padding: 0;
        margin: 20px auto 0 auto;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<div class="container flex flex-col w-11/12 sm:w-3/5 text-center m-auto h-auto">
    <div class="ml-10 mt-5">
        <br>
    </div>
    <div class="mb-5 text-4xl sm:text-[52px] text-center">
        <img src="<?php echo e(URL::asset('img/login/Registro exitoso.png')); ?>" class="w-1/4 mx-auto" alt="">
        <br>
        <h1 class="titulos tracking-wide">¡Listo!</h1>
    </div>
    
    <div>
        <h4 class="lg:px-40 md:px-28 my-5 font-semibold tracking-wide text-[23px] text-[#8b8484]">Se ha creado la siguiente cuenta:</h4>
    </div>
    
    <div>
        <h2 class="text-[38px] text-[#03a452] titulos tracking-wide"><em>usuario01@gmail.com</em></h2>
    </div>

    <div>
        <p class="lg:px-24 md:px-20 my-5 font-semibold tracking-wide text-[22px] text-[#8b8484]">
            Puedes usar esta cuenta para comentar y estar al tanto de las noticias y novedades, también puedes
            iniciar desde cualquier dispositivo.
        </p>
    </div>

    <div class="text-center flex justify-center space-x-2 mt-2">
        <a href="<?php echo e(route('home.index')); ?>" class="font-black tracking-wide text-3xl">Volver   </a> 
        <img src="img/login/Icono Salir Azul.png" class="w-7 h-7" alt="">
    </div>

    <br><br>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ingreso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testprevycons\project-prevycons\resources\views/login/success.blade.php ENDPATH**/ ?>